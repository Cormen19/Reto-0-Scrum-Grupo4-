
/**
 * Erabiltzaile bat izan ahal dituen funtzioak
 */
public enum Permisos {
	/** Empleado */
	EMPLEADO,
	/**Administrador */
	ADMINISTRADOR
}
